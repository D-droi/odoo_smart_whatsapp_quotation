# This file can be used to import model files when you add them
# For example: from . import sale_order 
from . import sale_order
from . import res_config_settings 