# Smart WhatsApp Quotation - App Store Assets

This folder contains the required assets for App Store submission.

## Required Files

### 1. icon.png
- **Size**: 512x512 pixels
- **Format**: PNG with transparency support
- **Content**: Icon representing quotation/document + WhatsApp integration
- **Colors**: Use WhatsApp green (#25D366) and professional colors
- **Style**: Clean, modern, professional design

### 2. screenshot1.png
- **Size**: Minimum 1200x800 pixels
- **Format**: PNG
- **Content**: Sale Order form view with "Send via WhatsApp" button
- **Key Elements**:
  - Header with "Send via WhatsApp" button
  - WhatsApp tab in notebook
  - Quotation line items
  - Customer information
  - Professional Odoo interface

### 3. screenshot2.png
- **Size**: Minimum 1200x800 pixels
- **Format**: PNG
- **Content**: Settings > General Settings page
- **Key Elements**:
  - "Default WhatsApp Template" field
  - Help text explaining placeholders
  - Example template with {customer_name} and {pdf_url}
  - Save/Apply buttons

## Image Guidelines

### General Requirements
- High quality, professional appearance
- Clear visibility of key features
- Consistent with Odoo design language
- No sensitive or confidential information
- Proper aspect ratios

### Technical Specifications
- PNG format for all images
- No compression artifacts
- Proper color profiles
- Suitable for web display

### Content Guidelines
- Show real functionality, not mockups
- Include actual Odoo interface elements
- Demonstrate key features clearly
- Professional business context

## Replacement Instructions

1. Replace the placeholder text files with actual PNG images
2. Ensure all images meet the size and quality requirements
3. Test images display correctly in Odoo App Store
4. Verify no sensitive data is visible in screenshots

## Notes

- These placeholder files will be replaced before App Store submission
- All images should be tested in the actual Odoo environment
- Consider creating multiple screenshots for better App Store presentation 